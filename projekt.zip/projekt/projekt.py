import pygame
from sys import exit
from random import randint
from math import sin, cos, radians

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        
        player_idle1 = pygame.image.load('grafika/idle/Idle1.png').convert_alpha()
        player_idle2 = pygame.image.load('grafika/idle/Idle2.png').convert_alpha()
        player_idle3 = pygame.image.load('grafika/idle/Idle3.png').convert_alpha()
        player_idle4 = pygame.image.load('grafika/idle/Idle4.png').convert_alpha()
        self.player_idle = [player_idle1,player_idle2,player_idle3,player_idle4]
        player_run1 = pygame.image.load('grafika/run/Run1.png').convert_alpha()
        player_run2 = pygame.image.load('grafika/run/Run2.png').convert_alpha()
        player_run3 = pygame.image.load('grafika/run/Run3.png').convert_alpha()
        player_run4 = pygame.image.load('grafika/run/Run4.png').convert_alpha()
        player_run5 = pygame.image.load('grafika/run/Run5.png').convert_alpha()
        player_run6 = pygame.image.load('grafika/run/Run6.png').convert_alpha()
        self.player_run = [player_run1,player_run2,player_run3,player_run4,player_run5,player_run6]
        
        self.player_index = 0
        
        self.image =  self.player_idle[self.player_index]
        self.rect = self.image.get_rect(midbottom = (40,370))
        #self.direction = 1
        self.is_moving = False
        #self.is_dead = False
        
    def player_input(self):
        self.is_moving = False
        keys = pygame.key.get_pressed()
        if keys[pygame.K_d]: 
            self.rect.x += 5
            #self.direction = 1 
            self.is_moving = True 
        if keys[pygame.K_a]:  
            self.rect.x -= 5
            #self.direction = -1
            self.is_moving = True
    
    def animation_state(self):
        if self.is_moving: 
            self.player_index += 0.1
            if self.player_index >= len(self.player_run):
                self.player_index = 0
            self.image = self.player_run[int(self.player_index)]
        else: 
            self.player_index += 0.1
            if self.player_index >= len(self.player_idle):
                self.player_index = 0
            self.image = self.player_idle[int(self.player_index)]
    
    def reset(self):
        if self.rect.x <= -1:
            self.rect.x = 20
              
    def update(self):
        self.player_input()
        self.animation_state()
        self.reset()
  
class Wall(pygame.sprite.Sprite):
    def __init__(self, x):
        super().__init__()
        
        self.image = pygame.image.load('grafika/wall.png').convert()
        self.rect = self.image.get_rect(midbottom = (x,350))

class Lights(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.light_radius = 400  
        self.light_angle = 45  
        self.light_direction = 1  
        self.light_speed = 1  
        self.light_polygon = []
        
        self.image = pygame.Surface((800, 400), pygame.SRCALPHA)
        self.rect = self.image.get_rect(topleft=(0, 0))
        
        self.light_center = (400, 200)

    def calculate_light_polygon(self, walls):
        light_points = [self.light_center]
        angle_step = 1  

        for angle in range(self.light_angle - 20, self.light_angle + 21, angle_step):
            rad_angle = radians(angle)
            end_x = self.light_center[0] + self.light_radius * cos(rad_angle)
            end_y = self.light_center[1] + self.light_radius * sin(rad_angle)
            ray_end = (end_x, end_y)

            closest_point = ray_end
            for wall in walls:
                clip_result = wall.rect.clipline(self.light_center, ray_end)
                if clip_result:
                    distance_to_wall = ((clip_result[0][0] - self.light_center[0])**2 +
                                        (clip_result[0][1] - self.light_center[1])**2)
                    distance_to_closest = ((closest_point[0] - self.light_center[0])**2 +
                                           (closest_point[1] - self.light_center[1])**2)
                    if distance_to_wall < distance_to_closest:
                        closest_point = clip_result[0]

            light_points.append(closest_point)
        self.light_polygon = light_points

    def draw_light(self, walls):
        if not self.light_polygon:
            self.calculate_light_polygon(walls)
        self.image.fill((0, 0, 0, 0))
        pygame.draw.polygon(self.image, (255, 255, 0, 100), self.light_polygon)


    def is_player_in_light(self, player, walls):
        if not self.light_polygon:
            self.calculate_light_polygon(walls)
        light_surface = pygame.Surface((800, 400), pygame.SRCALPHA)
        pygame.draw.polygon(light_surface, (255, 255, 0), self.light_polygon)
        light_mask = pygame.mask.from_surface(light_surface)

        offset_x = player.rect.x - self.rect.x
        offset_y = player.rect.y - self.rect.y

        return light_mask.overlap(pygame.mask.Mask(player.rect.size, True), (offset_x, offset_y)) is not None

    def update(self, walls):
        self.light_angle += self.light_speed * self.light_direction
        if self.light_angle > 120 or self.light_angle < 30: 
            self.light_direction *= -1
        self.light_polygon = []
        self.draw_light(walls)


def win():
    screen.fill('yellow')  
    victory_message = pygame.font.Font(None, 50).render('Victory!', True, ('black'))
    victory_rect = victory_message.get_rect(center=(400, 200))
    screen.blit(victory_message, victory_rect)

def intro():
    game_name = pygame.font.Font(None,50).render('Latarnia',False,('black'))
    game_name_rect = game_name.get_rect(center=(400,80))
    game_message = pygame.font.Font(None,25).render('Press Space to run',False,('black'))
    game_message_rect = game_message.get_rect(center=(400,330))
    
    screen.fill('yellow')
    screen.blit(game_name,game_name_rect)
    screen.blit(game_message,game_message_rect)
          
def death():
    death_time = pygame.time.get_ticks() 
    while pygame.time.get_ticks() - death_time < 2000:
        screen.fill('black')  
        died_message = pygame.font.Font(None, 50).render('You Died', True, ('red'))
        died_rect = died_message.get_rect(center=(400, 200))
        screen.blit(died_message, died_rect)
        pygame.display.update()
        clock.tick(60)

          
pygame.init()

screen = pygame.display.set_mode((800,400))
pygame.display.set_caption('Game')
clock = pygame.time.Clock()
x_pos = [randint(100, 700)]
game_on = False

player = pygame.sprite.GroupSingle()
player.add(Player())

x_pos = [(randint(-100,50))]
walls_group = pygame.sprite.Group()

light_group = pygame.sprite.Group()
light_group.add(Lights())

for i in range(4):  
    new_x =  x_pos[-1]+ randint(138,200)
    x_pos.append(new_x)
    walls_group.add(Wall(new_x))

floor_surf = pygame.image.load('grafika/floor.png').convert() 
lighthouse_surf = pygame.image.load('grafika/light.png').convert()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if not game_on and event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            game_on = True

    if game_on:
        screen.fill('black')        
        screen.blit(lighthouse_surf, (370, 150))  
        screen.blit(floor_surf, (0, 350))  

        light_group.update(walls_group)  
        light_group.draw(screen)  

        walls_group.draw(screen)  
        player.draw(screen)  
        player.update()  

        
        if light_group.sprites()[0].is_player_in_light(player.sprite, walls_group):
            death()
            player.sprite.rect.midbottom = (40, 370)  
            game_on = False
            
            
        if player.sprite.rect.x >= 800:  
            win()
    else:
        intro()

    pygame.display.update()
    clock.tick(60)